import serial
import time

#time.sleep(3)
#with  serial.Serial('/dev/tty.usbmodem1421', 115200) as ser:
#	time.sleep(3)
#	while True:
#		str = ser.readline()
#		print (ser.readline())

#		if "Send any character to" in str:
#			ser.write('2')
#			break;
#	ser.close()


#a = raw_input('2')
#str = ('%s'%('2'))
#print(str)
#ser.write(str)
#set.close()
#ser.open()
#print(ser.readline())
#print(ser.readline())

#ser.write(a)
#ser.write("2")
#ser = serial.Serial('/dev/tty.usbmodem1421', 115200, timeout=5.0)
ser = serial.Serial('/dev/tty.usbmodem1421', 115200)
#c= ser.read()
#str = ser.read(10000)
#line = ser.readline()
#print(line)
#ser.close()
while True:
	print (ser.readline())
