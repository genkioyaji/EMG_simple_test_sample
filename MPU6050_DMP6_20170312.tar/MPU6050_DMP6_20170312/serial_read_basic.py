import serial

ser = serial.Serial('/dev/tty.usbmodem1421', timeout=1)
c= ser.read()
str = ser.read(1000)
line = ser.readline()
print(line)
ser.close()