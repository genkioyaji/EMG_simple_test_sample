import serial
import time
ser = serial.Serial('/dev/tty.usbmodem1421', 38400)
time.sleep(3)
#a = raw_input('2')
#str = ('%s'%('2'))
#print(str)
#ser.write(str)
#set.close()
print(ser.readline())
print(ser.readline())

#ser.write(a)
#ser.write("2")
while True:
	print (ser.readline())
